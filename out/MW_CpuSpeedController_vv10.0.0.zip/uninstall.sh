rm -rf /data/powercfg.sh
rm -rf /data/powercfg.json
rm -rf /sdcard/Android/MW_CpuSpeedController
rm -rf /data/powercfg
pm uninstall io.github.xsheeee.cs_controller
echo "卸载CS调度成功完成 请重启手机"